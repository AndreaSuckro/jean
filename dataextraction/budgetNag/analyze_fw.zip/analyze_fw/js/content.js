"use strict";

var budgetLeft = 75;

var budgetsLeft = {
    "Electronics": 25.0,
    "Clothing": 75.0
}

var mintBaseUrl = "https://stage.mint.com/";

// Get the category for later
if ($('#add-to-cart-button').length > 0) {
    // We're on a product page, get the category
    var category = $('#SalesRank').eq(0).text();
    var inLoc = category.indexOf(' in ') + 4;
    var catEnd = category.indexOf(' ', inLoc);
    category = category.substring(inLoc, catEnd);
    console.log('category: ' + category);
    localStorage.setItem("mintAdvisorCategory", category);
}


var prices = [];
$('.hlb-item-stats>.hlb-price').each(function() {
    prices.push($(this).text().trim());
});

var $checkoutButton = $('.hlb-checkout-button');

$('<div id="mintBudgetAlert"></div>').appendTo('body');
var $popup = $('#mintBudgetAlert');

if ($checkoutButton.length && prices.length && (parseFloat(prices[0].replace('$', '')) - budgetLeft > 0)) {
    var itemName = $('.hlb-item-link').text();
    var itemPrice = parseFloat(prices[0].replace('$', '')).toFixed(2);
    var amountExceedingBudget = (itemPrice - budgetLeft).toFixed(2);
/*
    $('#mintAdvisor').append('<ul></ul>');
    prices.forEach(function(nextPrice, index) {
        $('#mintAdvisor ul').append('<li>' + nextPrice + '</li>');
    });
*/
    var categoryStr = '';
    var savedCategory = localStorage.getItem('mintAdvisorCategory');
    if (savedCategory != false) {
        switch (savedCategory.toLowerCase()) {
            case 'shoes':
                savedCategory = 'Clothing';
        }
        categoryStr = ' for <b>' + savedCategory + '</b>';
    }

    $popup.append('<h1>Oops!</h1>\n' +
        '<a id="closeMintBudgetAlert" href="#"></a>\n' +

        'This item puts you <b>$' + amountExceedingBudget + '</b> over budget.\n' +

        '<div class="item">\n' +
        '    <b>$' + itemPrice + '</b>&nbsp; ' + itemName.trim() + '\n' +
        '</div>\n' +

        'Are you sure you need this now?\n' +

        '<ul>\n' +
        '    <li>I guess not. Create a <a href="' + mintBaseUrl + 'goal.event" target="_blank">savings plan</a> on Mint</li>\n' +
        '    <li>Yes. <a href="' + mintBaseUrl + 'planning.event" target="_blank">Adjust my budget</a> on Mint</li>\n' +
        '    <li><a href="#" id="mintAdvisorClose">Go away</a>. I know what I\'m doing!</li>\n' +
        '</ul>\n' +

        '<div class="mintBranding"></div>\n');



/*
    $popup.append('<div class="mintAdvisorHeader"><img src="' + chrome.extension.getURL('icons/mint-advisor-logo.png') + '"></div>')
          .append('<div>You have added product <span class="addedItemName">' + itemName.trim() + '</span> for <span class="addedItemPrice">$' + itemPrice + '</span></div>')
          .append('<div><img src="' + chrome.extension.getURL('icons/cautionIcon.png') + '">This will exceed your budget' + categoryStr + ' by <span class="addedItemPrice">$' + amountExceedingBudget + '</span></div>');
    $popup.append('<div>Your choices are:</div>')
          .append('<ul><li>Remove this item from your cart</li>' +
            '<li>Create a savings plan in Mint. <a href="' + mintBaseUrl + 'goal.event" target="_blank">Click here</a></li>' +
            '<li>Adjust your Mint budget. <a href="' + mintBaseUrl + 'planning.event" target="_blank">Click here</a></li></ul>');
    $popup.append('<div><a href="#" id="mintAdvisorClose">Close</a></div>')
*/
    $popup.css('left', $checkoutButton.offset().left - ($popup.width()/2) + 220).css('top', $checkoutButton.offset().top - ($popup.height()/2));
    $popup.show();

    $('#mintAdvisorClose,#closeMintBudgetAlert').on('click', function() {
        $('#mintBudgetAlert').hide();
    });
}

/*
 * Step 1: Inject script to access QBO JavaScript.
 */

/*
var script = document.createElement("script");

// Note: The callback function executes asynchronously, only after the SiteCatalyst module has been loaded
script.text = "if (typeof require === 'function') { \n" + // Special case for QBO Harmony or other apps with Dojo
              "  require(['libs/sitecatalyst'], function (scode) { \n" +
              "    var wa = scode.wa; \n" +
              "    var pageName; \n" +
              "    var userName; \n" +
              "    var div; \n\n" +
              "    pageName = wa.getProp('pageName'); \n" +
              "    if (typeof qbo !== 'undefined' && qbo.user.name) { \n" +
              "      userName = qbo.user.name; \n" +
              "    } else { \n" +
              "      console.log('qbo is empty or not declared, or qbo.user.name does not exist'); \n" +
              "    } \n" +
              "    div = document.createElement('div'); \n" +
              "    div.setAttribute('id', 'analyze-it-browser-extension'); \n" +
              "    div.setAttribute('data-pagename', pageName); \n" +
              "    div.setAttribute('data-username', userName); \n" +
              "    document.body.appendChild(div); \n" +
              "  });\n" +
              "} \n" +
              "else if (typeof jQuery !== 'undefined') { \n" + // General jQuery case and special case for TTO
              "  jQuery(document).ready(function() { \n" +
              "    var pageName = 'UNKNOWN'; \n" +
              "    var userName = 'UNKNOWN'; \n" +
              "    if (typeof TTOModel !== 'undefined') { \n" +
              "      pageName = TTOModel.getDialogInfo().screenId; \n" + // Extracts page name from TTO object
              "      userName = 'TTO USER'; \n" + // We can't get actual user name for TTO, but can flag it was TTO.
              "    } \n" +
              "    else { \n" +
              "      pageName = $('body').attr('data-analyzeit-pagename'); \n" + // Extracts page name from body attribute data-analyzeit-pagename
              "    } \n" +
              "    if (typeof pageName !== 'undefined') { \n" +
              "      // console.log('pageName=' + pageName); \n" +
              "      var div = document.createElement('div'); \n" +
              "      div.setAttribute('id', 'analyze-it-browser-extension'); \n" +
              "      div.setAttribute('data-pagename', pageName); \n" +
              "      div.setAttribute('data-username', userName); \n" +
              "      document.body.appendChild(div); \n" +
              "    } \n" +
              "  }); \n" +
              "} \n" +
              "else { \n" + // General JavaScript case
              "  var pageName = 'UNKNOWN'; \n" +
              "  var offeringName = 'UNKNOWN'; \n" +
              "  if (document.getElementsByTagName(\"BODY\")[0].hasAttribute('data-analyzeit-pagename')) { \n" +
              "    pageName = document.getElementsByTagName(\"BODY\")[0].getAttribute('data-analyzeit-pagename'); \n" + // Extracts page name from body attribute data-analyzeit-pagename
              "  } \n" +
              "  if (document.getElementsByTagName(\"BODY\")[0].hasAttribute('data-analyzeit-offering')) { \n" +
              "    offeringName = document.getElementsByTagName(\"BODY\")[0].getAttribute('data-analyzeit-offering'); \n" + // Extracts offering name from body attribute data-analyzeit-offering
              "  } \n" +
              "  var div = document.createElement('div'); \n" +
              "  div.setAttribute('id', 'analyze-it-browser-extension'); \n" +
              "  div.setAttribute('data-pagename', pageName); \n" +
              "  div.setAttribute('data-offering', offeringName); \n" +
              "  document.body.appendChild(div); \n" +
              "}";
              // If none of the above cases are found, we will time out below.
document.body.appendChild(script);
*/

/*
 * Step 2: Check every 200 milliseconds whether s.pageName exists in the DOM. Time out after 10 seconds.
 */

/*
var div;
var pageName;
var userName;
var offeringName;
var counter = 0;

var watcher = setInterval(function() {
  div = document.getElementById("analyze-it-browser-extension");
  if (div) {
    pageName = div.getAttribute("data-pagename");
    userName = div.getAttribute("data-username");
    offeringName = div.getAttribute("data-offering");
  }
  if (pageName) {
    chrome.extension.sendMessage({
      "sender": "content",
      "message": "pageinfo",
      "url": document.URL,
      "pageName": pageName,
      "userName": userName,
      "offeringName": offeringName
    });
    document.body.removeChild(script);
    document.body.removeChild(div);
    clearInterval(watcher);
  }
  if (counter === 50) {
    chrome.extension.sendMessage({
      "sender": "content",
      "message": "timeout"
    });
    document.body.removeChild(script);
    clearInterval(watcher);
  }
  counter++;
}, 200);
*/
